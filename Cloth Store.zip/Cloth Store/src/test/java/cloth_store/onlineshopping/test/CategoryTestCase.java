package cloth_store.onlineshopping.test;

public class CategoryTestCase {

	/*private static AnnotationConfigApplicationContext context;

	private static CategoryDAO categoryDAO;
	private static Category category;

	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.isolutions4u.onlineshopping");
		context.refresh();

		categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
	}

	@Test
	public void testAddCategory() {
		category = new Category();

		category.setName("Television");
		category.setDescription("This is some description for television");
		category.setImageUrl("cat_1.png");
		category.setActive(true);

		assertEquals("Successfully added a category inside the table!", true, categoryDAO.add(category));
	}*/

}
