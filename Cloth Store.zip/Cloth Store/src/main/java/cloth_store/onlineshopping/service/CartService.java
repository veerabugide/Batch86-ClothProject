package cloth_store.onlineshopping.service;

import cloth_store.onlineshopping.model.Cart;

public interface CartService {

    boolean saveCart(Cart cart);

    boolean updateCart(Cart cart);

    Cart findCart();

}
