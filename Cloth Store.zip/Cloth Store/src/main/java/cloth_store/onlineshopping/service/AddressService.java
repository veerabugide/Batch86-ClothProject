package cloth_store.onlineshopping.service;

import cloth_store.onlineshopping.model.Address;

public interface AddressService {

    boolean saveAddress(Address address);

    Address findAddressByBilling(boolean billing);

}
